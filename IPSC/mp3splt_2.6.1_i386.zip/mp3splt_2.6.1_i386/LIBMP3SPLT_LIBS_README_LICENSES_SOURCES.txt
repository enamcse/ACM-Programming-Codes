Source code can be found here:
  http://mp3splt.sourceforge.net/mp3splt_page/windows_build.php
as a link to here:
  http://prdownloads.sourceforge.net/mp3splt/libmp3splt_mingw_required_libs_sources.tar.bz2
and here for libmp3splt:
  http://mp3splt.sourceforge.net/mp3splt_page/downloads.php

See licenses in the libmp3splt_libs_licenses directory.